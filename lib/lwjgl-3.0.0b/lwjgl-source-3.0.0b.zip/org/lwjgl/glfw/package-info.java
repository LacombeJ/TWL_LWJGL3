/**
 * Provides the classes necessary for GLFW.
 *
 * @see <a href="http://www.glfw.org/">glfw.org</a>
 */
package org.lwjgl.glfw;
